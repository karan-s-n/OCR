package org.example;

import org.apache.commons.io.IOUtils;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.jsoup.Jsoup;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Main {
    private static final CloseableHttpClient client = HttpClientBuilder.create().build();
    private static final String PATH = "/Users/karansinghnayal/Documents/BGS DATA/FetchedImages/";
    private static final AtomicInteger totalCount = new AtomicInteger();
    private static final AtomicInteger successCount = new AtomicInteger();


    private static final ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(20);

    public static void main(String[] args) {

        List<Map.Entry<Future, String>> tasks = new ArrayList<>();
        Timer timer = new Timer("timer");
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                System.out.println(LocalDateTime.now() + " Total Tasks Executed:" + totalCount.get());
            }
        }, 0l, 5000L);
        try (Scanner myReader = new Scanner(new File(PATH + "BGS.txt"))) {
            while (myReader.hasNextLine()) {
                String bgsId = myReader.nextLine();
                if (Files.exists(Path.of(PATH + bgsId + ".png")))
                    continue;

                tasks.add(Map.entry(executor.submit(() -> saveToFile(bgsId)), bgsId));
                if (tasks.size() == 50) {
                    for (Map.Entry<Future, String> task : tasks) {
                        try {
                            task.getKey().get(30, TimeUnit.SECONDS);
                        } catch (Exception e) {
                            System.out.println("Failed to process request for bgsId:" + task.getValue());
                        }
                    }
                    tasks.clear();
                }
            }
            for (Map.Entry<Future, String> task : tasks) {
                try {
                    task.getKey().get(30, TimeUnit.SECONDS);
                } catch (Exception e) {
                    System.out.println("Failed to process request for bgsId:" + task.getValue());
                }
            }


//            executor.shutdown();
//            while (!executor.isTerminated()) {
//                TimeUnit.SECONDS.sleep(5);
//                System.out.println("Waiting for threads:" + executor.getActiveCount() + " no of files read:" + totalCount.get());
//            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    private static void saveToFile(String bgsId) {
        String path = "https://scans.bgs.ac.uk/sobi_scans/boreholes/" + bgsId + ".html";
        try {
            var response = Jsoup.connect(path).ignoreHttpErrors(true).execute();
            totalCount.incrementAndGet();
            if (response.statusCode() == 200) {
                String imgPath = Optional.ofNullable(response.parse().select("img").first())
                        .map(img -> img.attr("src")).orElse("");
                if (imgPath.isBlank())
                    return;
                System.out.println(Thread.currentThread() + " totalCount = " + totalCount.get() + " succCount = " + successCount.incrementAndGet() + " path = " + path);
                writeToFile(imgPath, bgsId);

            }
        } catch (Exception e) {
            System.out.println("exception with bgsId:" + bgsId + " with error:" + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void writeToFile(String imgPath, String bgsId) throws Exception {
        OutputStream outputStream = Files.newOutputStream(Path.of(PATH + bgsId + ".png"));
        IOUtils.copy(client.execute(new HttpGet(imgPath)).getEntity().getContent(), outputStream);
        outputStream.flush();
        outputStream.close();

    }
}